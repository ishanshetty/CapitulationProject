#!/usr/bin/env python3

import socket
import sys #sys.platform

class TCPClient:
	''' Simple TCP Client'''

	def __init__(self, nodelay=False, sock=None):
		if sock is None:
			self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
			if nodelay:
				self.sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
		else:
			self.sock = sock

	def connect(self, host, port):
		self.sock.connect((host, port))

	def send(self, msg):
		'''
		Return number of bytes sent.
		'''
		if isinstance(msg, str):
			return self.sock.send(msg.encode("utf-8"))
		else:
			return self.sock.send(msg)

	def sendall(self, msg):
		'''
		Send all the data, unless an error occurs, then an exception is raised
		'''
		if isinstance(msg, str):
			self.sock.sendall(msg.encode("utf-8"))
		else:
			self.sock.sendall(msg)

	def sendline(self, msg):
		self.sendall(msg)
		self.sendall(b'\n')

	def recv(self, length=1024, timeout=None):
		self.sock.settimeout(timeout)
		data = self.sock.recv(length)
		self.sock.settimeout(None)
		return data

	def recv_exact(self, length):
		data = bytearray()
		remaining = length
		while  remaining > 0:
			chunk = self.sock.recv(remaining)
			if not chunk: 
				raise EOFError
			data.extend(chunk)
			remaining -= len(chunk)
		return bytes(data)
	
	def peek_exact_immediate(self, length):
		if sys.platform == "win32": #work around missing socket.MSG_DONTWAIT
			try:
				self.sock.setblocking(False)
				data = self.sock.recv(length, socket.MSG_PEEK)
			finally:
				self.sock.setblocking(True)
		else:
			data = self.sock.recv(length, socket.MSG_PEEK | socket.MSG_DONTWAIT)
		if len(data) < length:
			raise BlockingIOError
		else:
			return data

	def recvline(self, timeout=None):
		self.sock.settimeout(timeout)
		f = self.sock.makefile()
		line = f.readline()
		self.sock.settimeout(None)
		return line

	def close(self):
		self.sock.close()

if __name__ == '__main__':
	c = TCPClient()
	c.connect('localhost', 45000)
	c.sendline('{}')
	try:
		print(c.recv(timeout=3))
	except:
		print('Timed out')
		
	print(c.recv())
	#print(c.recvline(timeout=3))
	c.close()