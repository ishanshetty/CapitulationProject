def zstd_decompress(compressed_chunk, uncompressed_size):
	import zstandard
	dctx = zstandard.ZstdDecompressor()
	dobj = dctx.decompressobj()
	data = dobj.decompress(compressed_chunk)
	return data

def lz4_decompress(compressed_chunk, uncompressed_size):
	import lz4.block
	data = lz4.block.decompress(compressed_chunk, uncompressed_size)
	return data

current_decompress_fn = None
def any_decompress(compressed_chunk, uncompressed_size):
	global current_decompress_fn

	if not current_decompress_fn:
		#discover which compression algo
		try:
			zstd_decompress(compressed_chunk, uncompressed_size)
		except:
			current_decompress_fn = lz4_decompress
		else:
			current_decompress_fn = zstd_decompress
	return current_decompress_fn(compressed_chunk, uncompressed_size)

class byteFIFO:
	""" byte FIFO buffer """
	def __init__(self):
		self._buf = bytearray()
		self.EOF = False

	def write(self, data):
		self._buf.extend(data)
		if len(data) == 0:
			self.EOF = True

	def read(self, size):
		data = self._buf[:size]
		# The fast delete syntax
		del self._buf[:size]
		return data

	#Non-blocking readline, return None if there is no subsequence ending in newline
	#On EOF returns the remaining data even if it doesn't end in newline
	def readline(self):
		newline_idx = self._buf.find(b'\n')
		if newline_idx >= 0:
			return self.read(newline_idx + 1)
		elif self.EOF and self.__len__():
			return self.read(self.__len__())
		else:
			return None

	def peek(self, size):
		return self._buf[:size]

	def getvalue(self):
		# peek with no copy
		return self._buf

	def __len__(self):
		return len(self._buf)
