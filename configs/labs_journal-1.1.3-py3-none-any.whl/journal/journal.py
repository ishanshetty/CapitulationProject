#!/usr/bin/env python3

from .utils import TCPClient
import json
import struct
import sys
import argparse

'''
Field Name		Offset	Length	Type/Value		Description
Request Id		0		4		Binary Integer	Identifies the request
Payload Size	4		4		Binary Integer	Size of payload (N)
Flags			8		1		Bitmask			Request flags. See ‘Flags’ table.
Status Code		9		1		Binary Integer	Request status. See ‘Status Code’ table.
Payload			10		N		(mixed)			Payload data.

Flags:
Bit 			Description
0x01			End of request
0x02			Server metadata
0x04			Compressed

Status Codes:
Code 			Description
0 				No error
1 				Resource not found
'''

class RequestError(Exception):
	def __init__(self, message, status_code):
		super(RequestError, self).__init__(message)
		self.status_code = status_code

class SessionFuture(object):
	def __init__(self, session, req_id, callback, oob_callback, error_callback):
		self.session = session
		self.request_id = req_id
		self.callback = callback
		self.oob_callback = oob_callback
		self.error_callback = error_callback
		self.status_code = None
		self.error_message = None
		self.error = None
		self.is_cancelled = False

	def wait(self):
		self.session._wait(self.request_id)
	
	def cancel(self):
		self.session._cancel(self.request_id)
		self.is_cancelled = True

	def _make_exception_from_status(self):
		if self.status_code == None:
			return RequestError(self.error_message, self.status_code)
		elif self.status_code > 0:
			return RequestError(self.error_message, self.status_code)
		return None

	def raise_on_error(self):
		if self.error:
			raise self.error

		e = self._make_exception_from_status()
		if e:
			raise e


class Session(object):
	'''
		Asynchronous request handler
	'''
	def __init__(self, host=None, port=None, decompress_fn=None):
		self.host = host
		self.port = port
		self.next_request_id = 1
		self.futures = dict()
		self.decompress_fn = decompress_fn

		if host and port:
			self.connect(self.host, self.port)

	def connect(self, host=None, port=None):
		self.sock = TCPClient(nodelay=True)
		self.sock.connect(host, port)

	def close(self):
		self.host = None
		self.port = None
		self.sock.close()

	def __enter__(self):
		return self
	def __exit__(self, etype, value, traceback):
		self.wait()
		self.close()

	def _post_request(self, request_id, request_str, callback=None, oob_callback=None, error_callback=None):
		'''
		Post request.
		callback 		- callback for in band data buffers
		oob_callback 	- callback for out of band data
		'''
		future = SessionFuture(self, request_id, callback, oob_callback, error_callback)
		self.futures[request_id] = future
		self.sock.sendline(request_str)
		return future

	def outstanding_request_count(self):
		return len(self.futures)

	def _wait(self, request_id):
		while request_id in self.futures:
			self.wait(1)
	
	def _cancel(self, request_id):
		r = { 'action': 'cancel', 'target-request-id': request_id};
		self.request(r)

	def _handle_frame(self, req_id, payload_size, uncompressed_payload_size, flags, status_code, data):
		'''
		Calls the appropriate handlers.
		Returns True if this frame finalizes the request
		'''

		#print('_handle_frame(%d, %d, %s, %d, %d, %s)' % (req_id, payload_size, uncompressed_payload_size, flags, status_code, data))

		h = self.futures[req_id]
		
		if not h.error:
			try:
				if flags & 0x04:
					if not self.decompress_fn:
						raise Exception('No decompression function provided')
					data = self.decompress_fn(data, uncompressed_payload_size)
				
				if not h.is_cancelled:
					if flags & 0x02 and h.oob_callback and data:
						h.oob_callback(data)
					elif not flags & 0x02 and h.callback and data:
						h.callback(data)
			except Exception as e:
				h.error = e
				if h.error_callback:
					h.error_callback(self, h)

		if flags & 0x01:
			h.status_code = status_code
			if flags & 0x02 and data:
				h.error_message = data
			
			if not h.error:
				try:
					if h.callback:
						h.callback(b'') #end of request
					if h.oob_callback:
						h.oob_callback(b'')
				except Exception as e:
					h.error = e

			del self.futures[req_id]
			return True
		return False
			
	def try_wait(self):
		'''
		A non-blocking event loop that will read until there are no complete frames available.
		'''
		#print('try_wait')

		#Do I have one complete frame?

		try:
			#Do I have one complete header?
			header_len = 10
			header = self.sock.peek_exact_immediate(header_len) #throws BlockingIOError
			assert(len(header) == header_len)
				
			req_id, payload_size, flags, status_code = struct.unpack('>IIBB', header)
			uncompressed_payload_size = None

			if flags & 0x04:
				#It is compressed: Do I have one complete header again?
				header_len = header_len + 4
				header = self.sock.peek_exact_immediate(header_len) #throws BlockingIOError
				assert len(header) == header_len
				uncompressed_payload_size, = struct.unpack('>I', header[10:])

			#Do I have one complete header + payload (i.e. frame)?
			frame = self.sock.peek_exact_immediate(header_len + payload_size) #throws BlockingIOError
			assert len(frame) == header_len + payload_size
		except BlockingIOError as e:
			return False #We don't have a complete frame in socket buffer
		
		#Now actually pop the frame off the socket. This operation should not block
		data = self.sock.recv_exact(header_len + payload_size)[header_len:]
		assert len(data) == payload_size
		
		self._handle_frame(req_id, payload_size, uncompressed_payload_size, flags, status_code, data)
		return True
				
	def wait(self, max_count=None):
		'''
		Block and read posted requests.
		If max_count is specified will read at most count requests
		'''
		assert(max_count == None or max_count > 0)
		#print('wait: max_count=%s' % str(max_count))
		
		finished_count = 0
		#Read Reply
		while self.outstanding_request_count(): #Pending requests
			header = self.sock.recv_exact(length=10)
			if len(header) < 10:
				break
			req_id, payload_size, flags, status_code = struct.unpack('>IIBB', header)
			uncompressed_payload_size = None

			if flags & 0x04:
				opt_header = self.sock.recv_exact(length=4)
				assert len(opt_header) == 4

				uncompressed_payload_size, = struct.unpack('>I', opt_header)

			data = self.sock.recv_exact(payload_size)
			assert len(data) == payload_size
			
			is_finished = self._handle_frame(req_id, payload_size, uncompressed_payload_size, flags, status_code, data)
			
			if is_finished:
				finished_count += 1
				if max_count and finished_count >= max_count:
					break
	
	def request(self, fields, callback=None, oob_callback=None, error_callback=None):
		request = fields.copy()
		
		request_id = self.next_request_id
		self.next_request_id += 1
		
		request['id'] = request_id
		request_str = json.dumps(request)
		#print(request_str)
		h = self._post_request(request_id, request_str, callback, oob_callback, error_callback)
		
		return h

	def update_request(self, future, fields):
		'''
		Update existing request.
		'''
		assert future.request_id in self.futures

		request = fields.copy()
		request['id'] = future.request_id
		request_str = json.dumps(request)
		#print(request_str)
		self.sock.sendline(request_str)
	

def _stdout_writer(data):
	sys.stdout.buffer.write(data)
	sys.stdout.buffer.flush()
def _stderr_writer(data):
	sys.stderr.buffer.write(data)
	sys.stderr.buffer.flush()

def run_interactive(host, port, on_data=_stdout_writer, on_oob=_stderr_writer, on_connect=None, on_error=None, on_new_request=None):
	import signal
	handle = None
	original_sigint_handler = signal.getsignal(signal.SIGINT)

	def signal_handler(sig, frame):
		if handle:
			sys.stderr.write('Cancelling active request...\n')
			handle.cancel()
		else:
			original_sigint_handler(sig, frame)
	signal.signal(signal.SIGINT, signal_handler)

	from . import utils
	with Session(host, port, utils.any_decompress) as session:
		if on_connect:
			on_connect(session)
		
		for line in sys.stdin:
			if line == '':
				continue
			try:
				request_fields = json.loads(line)
				if not isinstance(request_fields, dict):
					raise ValueError()
			except ValueError:
				sys.stderr.write('Invalid JSON request!\n')
				continue

			if on_new_request:
				on_new_request(request_fields)

			handle = session.request(request_fields, on_data, on_oob, on_error)
			handle.wait()
			try:
				handle.raise_on_error()
			except RequestError as e:
				sys.stderr.write('Request failed <{}>: {}\n'.format(e.status_code, str(e)))
			finally:
				handle = None

def simple_send_command(host, port, command, callback=None, on_connect=None):
	from . import utils
	with Session(host, port, utils.any_decompress) as session:
		if on_connect:
			on_connect(session)
		try:
			if isinstance(command, str):
				request_fields = json.loads(command)
				if not isinstance(request_fields, dict):
					raise ValueError()
			else:
				request_fields = command
		except ValueError:
			sys.stderr.write('Invalid JSON request!\n')

		handle = session.request(request_fields, callback)
		handle.wait()
		try:
			handle.raise_on_error()
		except RequestError as e:
			sys.stderr.write('Request failed with status code: ' + str(e.status_code) + '\n')

def shel_connect_main():
	parser = argparse.ArgumentParser(description='Communicate with server implementing Framing API')
	parser.add_argument('hostname', help='Hostname or IP')
	parser.add_argument('port', type=int, help='Port')
	args = parser.parse_args()

	run_interactive(args.hostname, args.port)

	

if __name__ == '__main__':
	shel_connect_main()
