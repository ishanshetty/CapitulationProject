from .. import Session
import os
import json
from functools import partial


def uniq(alist):
	uniq_list=[]
	for i in alist:
		if i not in uniq_list:
			uniq_list.append(i)
	return uniq_list

def xuniq(alist):
	uniq_list=[]
	for i in alist:
		if i not in uniq_list:
			yield i
	return uniq_list


class PlayerSession(Session):
	'''
		Adds data player specific calls for conveniece
	'''

	def list(self, fields):
		'''
		Return iterable of records
		'''
		request = fields.copy()

		request_id = self.next_request_id
		self.next_request_id += 1
		
		request['id'] = request_id
		request['action'] = 'list'
		request_str = json.dumps(request)

		class ListHandler(object):
			def __init__(self, fields):
				self.buffer = bytearray()
				self.records = []
				self.request_fields = fields

			def handler(self, data):
				if data:
					self.buffer.extend(data)
					return
				else: #End of reply
					if not self.buffer:
						return
					data_str = self.buffer.decode('utf-8')
					response = json.loads(data_str)

					if isinstance(response, dict) and 'symbols' in response: #V1 
						for symbol in response['symbols']:
							record = {'symbol': symbol}
							record.update(self.request_fields)
							self.records.append(record)
					elif isinstance(response, list): #V2
						self.records = xuniq(response) #uniq
					else:
						raise ValueError('Unknown response: ' + str(response))

		r = ListHandler(fields)
		future = self._post_request(request_id, request_str, callback=r.handler)
		
		future.wait()
		future.raise_on_error()
		
		return r.records
	
	def retrieve_all(self, fields, get_callback):
		thread_count = 1
		thread_fiber_count = 25
		self.request({'action':'set-property','what':'pool-size','value':thread_count})
		self.request({'action':'set-property','what':'pool-worker-max-tasks','value':thread_fiber_count})
		self.wait()

		records = self.list(fields)
		#Request each
		for r in records:
			r.update(fields)
			r['action'] = 'request'
			#print(str(r))
			cb = get_callback(r)
			self.request(r, callback=cb)
			if self.outstanding_request_count() > 2*thread_count*thread_fiber_count:
				self.wait(self.outstanding_request_count()/2)

		self.wait()

#Routines that use a session object to communicate with server
def run_with_config(host, port, config):
	def get_filename(r):
		def add_field(record, filename, *fields):
			for f in fields:
				if record.get(f):
					if len(filename):
						filename += '_'
					filename += r.get(f)
					return filename
			return filename
		filename = ''
		filename = add_field(r, filename, 'symbol_', 'symbol', 'root_', 'root')
		print(r)
		filename = add_field(r, filename, 'instrument_type_', 'instrument-type')
		filename = add_field(r, filename, 'country_code_', 'country-code')
		filename = add_field(r, filename, 'journal_type_', 'journal-type')
		filename = add_field(r, filename, 'date', 'date_')
		return filename + '.dat'

	def write_to_file(fp, data):
		fp.write(data)
		if not len(data):
			fp.close()

	def make_callback(record):
		dest = config['dest']
		filepath = os.path.join(dest, get_filename(record))
		fp = open(filepath, 'wb')
		return partial(write_to_file, fp)
		
	with PlayerSession(host, port) as session:
		dest = config['dest']
		os.makedirs(dest, exist_ok=True)
		fields = config['fields']
		if config['action'] == 'retrieve':
			fields['action'] = 'request'
			cb = make_callback(config['fields'])	
			session.request(config['fields'], callback=cb)
		elif config['action'] == 'dump':
			os.makedirs(dest, exist_ok=True) #Create folder
			session.retrieve_all(config['fields'], make_callback)



class SimpleJsonSession(Session):
	'''
		Simple wrapper that makes synchronous requests and expects
		responses in JSON format
	'''

	def request(self, fields, multi=False):
		'''
		Return iterable of records
		'''
		request = fields.copy()

		request_id = self.next_request_id
		self.next_request_id += 1
		
		request['id'] = request_id
		request_str = json.dumps(request)

		def yield_multiple_json_values(vals_str):
			'''
			parses multiple JSON values from string.
			'''
			decoder = json.JSONDecoder()
			while vals_str:
				val, n = decoder.raw_decode(vals_str)
				#remove the read characters from the start.
				vals_str = vals_str[n:]
				# remove leading white space because a second call to decoder.raw_decode()
				# fails when the string starts with whitespace, and
				# I don't understand why...
				vals_str = vals_str.lstrip()
				yield val
			return


		class JsonHandler(object):
			def __init__(self, fields):
				self.buffer = bytearray()
				self.response = None
				self.request_fields = fields

			def handler(self, data):
				if data:
					self.buffer.extend(data)
				else: #End of reply
					if not self.buffer:
						return
					data_str = self.buffer.decode('utf-8')
					if multi:
						self.response = yield_multiple_json_values(data_str)
					else:
						self.response = json.loads(data_str)

		r = JsonHandler(fields)
		future = self._post_request(request_id, request_str, callback=r.handler)
		
		future.wait()
		future.raise_on_error()
		
		return r.response
	

def player_main_impl(mode):
	import argparse
	parser = argparse.ArgumentParser(description='List ')
	
	parser.add_argument('hostname', help='Hostname or IP')
	parser.add_argument('port', type=int, help='Port')
	
	parser.add_argument('--journal', help='journal-type')
	parser.add_argument('--date', help='yyyy-mm-dd')
	parser.add_argument('--market', help='ins_type:ccode')
	parser.add_argument('--symbol', help='symbol')
	parser.add_argument('--root', help='root')
	parser.add_argument('--account', help='account')
	parser.add_argument('--entity', help='account')
	
	if mode == 'dump':
		parser.add_argument('--dest', required=True, help='Destination folder to dump resources')

	args = parser.parse_args()
	
	def get_fields(args):
		fields = {}
		if args.journal:
			fields['journal-type'] = args.journal
		if args.date:
			fields['date'] = args.date
		if args.market:
			(instype, ccode) = args.market.split(':')
			fields['instrument-type'] = instype
			fields['country-code'] = ccode
		if args.symbol:
			fields['symbol'] = args.symbol
		if args.root:
			fields['root'] = args.root
		if args.account:
			fields['account'] = args.account
		return fields
	
	if mode == 'list':
		with PlayerSession(args.hostname, args.port) as session:	
			records = session.list(get_fields(args))
			for r in records:
				print(r)
	elif mode == 'retrieve':
		import sys
		def _stdout_writer(data):
			sys.stdout.buffer.write(data)
			sys.stdout.buffer.flush()

		with PlayerSession(args.hostname, args.port) as session:
			req = get_fields(args)
			req['action'] = 'request'
			req['what'] = 'journal' #in case we're targeting DataEngine
			records = session.request(req, _stdout_writer)

	elif mode == 'dump':
		def write_to_file(fp, data):
			fp.write(data)
			if not len(data):
				fp.close()
		def make_callback(record):
			dest = args.dest
			filename = record.get('symbol_', record.get('root_', record.get('account_')))
			filename += '_' + record.get('instrument_type_')
			filename += '_' + record.get('country_code_')
			filename += '_' + record.get('journal_type_')
			filename += '_' + record.get('date_')
			filename += '.dat'
			print('Opening ' + filename)
			filepath = os.path.join(dest, filename)
			fp = open(filepath, 'wb')
			return partial(write_to_file, fp)
		
		os.makedirs(args.dest, exist_ok=True)

		with PlayerSession(args.hostname, args.port) as session:	
			records = session.retrieve_all(get_fields(args), make_callback)
	else:
		raise NotImplementedError()

def player_list_main():
	player_main_impl('list')
	
def player_retrieve_main():
	player_main_impl('retrieve')

def player_dump_main():
	player_main_impl('dump')
