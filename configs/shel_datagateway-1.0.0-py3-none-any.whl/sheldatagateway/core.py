#!/usr/bin/env python

import sys
import os
import journal.utils
import ujson #using ujson because it is a bit faster, you can swap in vanilla json
import datetime
import requests
import journal

class byteFIFO:
	""" byte FIFO buffer """
	def __init__(self):
		self._buf = bytearray()

	def write(self, data):
		self._buf.extend(data)

	def read(self, size):
		data = self._buf[:size]
		# The fast delete syntax
		del self._buf[:size]
		return data

	#Non-blocking readline, return None if there is no subsequence ending in newline
	def readline(self):
		newline_idx = self._buf.find(b'\n')
		if newline_idx == -1:
			return None
		return self.read(newline_idx + 1)

	def peek(self, size):
		return self._buf[:size]

	def getvalue(self):
		# peek with no copy
		return self._buf

	def __len__(self):
		return len(self._buf)


class AuthenticationError(Exception):
	def __init__(self, message, status_code):
		super(AuthenticationError, self).__init__(message)
		self.status_code = status_code

class Session(journal.Session):
	'''
		Wraps the Journal Session object, implementing  SHEL DataGateway API
	'''
	def __init__(self, environment, shel_user, shel_password):
		super().__init__(environment.SHEL_DATA_ENGINE_HOST, environment.SHEL_DATA_ENGINE_PORT, journal.utils.any_decompress)
		self.auth_token = os.getenv('TOKEN')
		if not self.auth_token:
			self.auth_token = self.authenticate(environment.SHEL_API_URL, shel_user, shel_password)

	def authenticate(self, shel_api_url, shel_user, shel_password):
		from requests.auth import HTTPBasicAuth
		from requests.compat import urljoin
		auth_url = urljoin(shel_api_url, 'auth')
		token_response = requests.post(auth_url, auth=HTTPBasicAuth(shel_user, shel_password))

		if token_response.status_code != 200:
			raise AuthenticationError(f"Authentication failed with status code: {token_response.status_code} {token_response.text}", token_response.status_code)
		
		return token_response.json()['token']


	class DataHandler(object):
		'''
		Wraps the users callback and handles the NDJSON parsing, calling the user callback with parsed dictionary objects
		'''
		def __init__(self, user_cb):
			self.pipe = byteFIFO()
			self.user_callback = user_cb
			
		def handle(self, data):
			self.pipe.write(data)
			#print('Wrote {} bytes\n'.format(len(data)))
			line = self.pipe.readline()
			while line :
				#print('Read Line: {} bytes: {}\n'.format(len(line), line))
				if line == '':
					return
				result = ujson.loads(line)
				if not isinstance(result, dict):
					raise ValueError('Expected a JSON object')
				
				self.user_callback(result)
				
				line = self.pipe.readline() #read next line

	def request_stream(self, callback, symbol, subscriptions=['trade','bar-1s']):
		'''
		The callback is called with parsed message objects (represented by dict)
		Returns a SessionFuture handle object which can be used to manage the request
		'''
		request_obj = {
			'action': 'request',
			'what': 'shel-datagateway-stream',
			'symbol': symbol,
			'subscriptions': subscriptions,
			'token': self.auth_token
		}

		return self.request(request_obj, self.DataHandler(callback).handle)

	def request_data(self, callback, symbol, start_date, end_date, subscriptions=['trade','bar-1s'], split_adjust=True):
		'''
		The callback is called with parsed message objects (represented by dict)
		Returns a SessionFuture handle object which can be used to manage the request
		'''
		request_obj = {
			'action': 'request',
			'what': 'shel-datagateway-data',
			'symbol': symbol,
			'start-date': start_date.isoformat(),
			'end-date': end_date.isoformat(),
			'split-adjust': split_adjust,
			'subscriptions': subscriptions,
			'token': self.auth_token
		}

		return self.request(request_obj, self.DataHandler(callback).handle)

from enum import Enum
class Mode(Enum):
	Stream = 1
	Data = 2

def main_impl(mode : Mode):
	import argparse
	import signal
	
	parser = argparse.ArgumentParser(description='Communicate with server implementing SHEL Open Data API')
	parser.add_argument('symbols', nargs='+', metavar='symbol', help='Symbol')

	group = parser.add_mutually_exclusive_group()
	group.add_argument('--prod-env', action='store_const', dest='env', const='prod', default='prod')
	group.add_argument('--staging-env', action='store_const', dest='env', const='staging')
	group.add_argument('--test-env', action='store', dest='env')

	parser.add_argument('-u', '--user', required=True, help='Login user')
	parser.add_argument('-p', '--password', help='Login password, if not given you will be prompted')
	
	parser.add_argument('--subscriptions', nargs='*', help='List of subscription types, e.g. trade bar-1s')
	parser.add_argument('--json', required=False, action ='store_true', help='Prints incoming messages as JSON rather than Python objects')
	
	if mode == Mode.Data:	
		dt_spec_group = parser.add_mutually_exclusive_group(required=True)
		dt_spec_group.add_argument('-d', '--date', help='Run for date given as yyyy-mm-dd')
		dt_spec_group.add_argument('-r', '--range', metavar='DATE', nargs=2, help='Run for the range of dates [$range[0], $range[1]]')

	args = parser.parse_args()

	subscription_list = ['trade'] if args.subscriptions is None else args.subscriptions
	
	handles = []
	def signal_handler(sig, frame):
		for h in handles:
			sys.stderr.write('Cancelling active request...\n')
			h.cancel()
		else:
			sys.exit(0)
	signal.signal(signal.SIGINT, signal_handler)

	flush_immediately = mode == Mode.Stream
	def print_object(obj):
		if args.json:
			print(ujson.dumps(obj, sys.stdout), flush=flush_immediately)
		else:
			print(obj, flush=flush_immediately)
	
	def _parse_date(dt_string):
		return datetime.datetime.strptime(dt_string, '%Y-%m-%d').date() if dt_string else datetime.date.today()
	
	#Select environment
	target_env = None
	from . import environments
	if args.env == 'prod':
		target_env = environments.env_defs.Prod
	elif args.env == 'staging':
		target_env = environments.env_defs.Staging
	else:
		(ip, port) = args.env.split(':')
		target_env = environments.env_defs.Environment(environments.env_defs.Staging.SHEL_API_URL, ip, int(port))

	if not args.password:
		import getpass
		args.password = getpass.getpass()

	with Session(target_env, args.user, args.password) as session:		
			for symbol in args.symbols: #subscribe to each symbol
				if mode == Mode.Stream:	
					h = session.request_stream(print_object, symbol, subscription_list)
				elif mode == Mode.Data:
					if args.date:
						begin_date = _parse_date(args.date)
						end_date = _parse_date(args.date)
					elif args.range:
						begin_date = _parse_date(args.range[0])
						end_date = _parse_date(args.range[1])
					else:
						assert False
					h = session.request_data(print_object, symbol, begin_date, end_date, subscription_list)
				handles.append(h)
			
			#block on all handles
			for h in handles:
				h.wait()
				try:
					h.raise_on_error()
				except journal.RequestError as e:
					sys.stderr.write('Request failed <{}>: {}\n'.format(e.status_code, str(e)))

def stream_main():
	main_impl(Mode.Stream)

def data_main():
	main_impl(Mode.Data)

#if __name__ == '__main__':
#	main()
