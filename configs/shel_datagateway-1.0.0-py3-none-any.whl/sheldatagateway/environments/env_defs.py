class Environment:
	def __init__(self, SHEL_API_URL, SHEL_DATA_ENGINE_HOST, SHEL_DATA_ENGINE_PORT):
		self.SHEL_API_URL = SHEL_API_URL
		self.SHEL_DATA_ENGINE_HOST = SHEL_DATA_ENGINE_HOST
		self.SHEL_DATA_ENGINE_PORT = SHEL_DATA_ENGINE_PORT


Staging = Environment('https://shel-staging.trilliumtrading.com:8443/api/data-gateway/v1/', 'nytdvdevbld01.idm.trlm.com', 65500)
Prod = Environment('https://shel.trilliumtrading.com:8443/api/data-gateway/v1/', 'datagateway.trlm.com', 65500)
